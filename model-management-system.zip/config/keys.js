module.exports = {
    mongoURI: "mongodb://root:wrc2018@ds129821.mlab.com:29821/wrc-mods",
    secretOrKey: "wrc2018!@#$", // used for passport jwt
    redisUrl: "redis://127.0.0.1:6379"
};